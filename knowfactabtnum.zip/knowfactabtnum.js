let inputEl = document.getElementById("userInput");
let factEl = document.getElementById("fact");

function getdata(event) {
    if (event.key === "Enter") {
        let inputVal = inputEl.value;
        let url = "https://apis.ccbp.in/numbers-fact?number=" + inputVal;
        let options = {
            method: "GET",
        };
        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                let {
                    fact
                } = jsonData;
                factEl.textContent = fact;
            });
    }
}
inputEl.addEventListener("keydown", getdata)